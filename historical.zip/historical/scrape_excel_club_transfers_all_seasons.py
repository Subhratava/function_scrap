import argparse
import asyncio
import json
import re
import uuid
from pathlib import Path
from urllib.parse import urlparse

import pandas as pd
from crawlee import Request
from crawlee.crawlers import ParselCrawler
from openpyxl import load_workbook

from tfmkt.crawlers.transfers import parse_transfer_table


DEFAULT_INPUT = Path("..") / "to_extract.xlsx"
DEFAULT_JSONL = Path("outputs") / "excel_club_transfers_all_seasons.json"
DEFAULT_XLSX = Path("outputs") / "excel_club_transfers_all_seasons.xlsx"


def clean_name(value: str | None) -> str | None:
    if not value:
        return None
    return " ".join(str(value).split()).strip() or None


def money_to_eur(value: str | None) -> float | None:
    if value is None:
        return None

    value = value.strip().replace(",", ".")
    if value in {"", "-", "?"}:
        return None
    if value == "free transfer":
        return 0.0
    if not value.startswith("\u20ac"):
        return 0.0

    amount = value[1:]
    multiplier = 1.0
    if amount.endswith("m"):
        multiplier = 1_000_000.0
        amount = amount[:-1]
    elif amount.endswith("k"):
        multiplier = 1_000.0
        amount = amount[:-1]

    try:
        return float(amount) * multiplier
    except ValueError:
        return None


def normalize_transfer_url(url: str) -> str:
    parsed = urlparse(url)
    path = parsed.path.rstrip("/")
    if "/saison_id/" in path:
        path = path.split("/saison_id/", 1)[0]
    path = path.replace("/startseite/", "/transfers/")
    path = path.replace("/alletransfers/", "/transfers/")
    return f"{parsed.scheme}://{parsed.netloc}{path}"


def season_url(base_transfer_url: str, season: int) -> str:
    return f"{base_transfer_url}/saison_id/{season}"


def extract_club_href(url: str) -> str:
    path = urlparse(url).path.rstrip("/")
    if "/saison_id/" in path:
        path = path.split("/saison_id/", 1)[0]
    return path


def read_club_links(input_file: Path, header_row: int, sheet_name: str | None = None) -> list[dict]:
    wb = load_workbook(input_file, data_only=False)
    if sheet_name:
        if sheet_name not in wb.sheetnames:
            raise ValueError(f"Sheet '{sheet_name}' not found. Available sheets: {', '.join(wb.sheetnames)}")
        ws = wb[sheet_name]
    else:
        ws = wb.active

    headers = {}
    for cell in ws[header_row]:
        value = clean_name(cell.value)
        if value:
            headers[value.lower()] = cell.column

    link_column = headers.get("link")
    club_name_column = headers.get("club name")
    if not link_column:
        raise ValueError(f"Could not find a 'Link' header in row {header_row}")

    clubs = []
    for row in range(header_row + 1, ws.max_row + 1):
        link_cell = ws.cell(row=row, column=link_column)
        link = link_cell.hyperlink.target if link_cell.hyperlink else link_cell.value
        link = clean_name(link)
        if not link:
            continue

        club_name = None
        if club_name_column:
            club_name = clean_name(ws.cell(row=row, column=club_name_column).value)

        clubs.append(
            {
                "input_row": row,
                "input_club_name": club_name,
                "input_url": link,
                "base_transfer_url": normalize_transfer_url(link),
            }
        )

    return clubs


def club_links_from_urls(urls: list[str]) -> list[dict]:
    clubs = []
    for index, url in enumerate(urls, start=1):
        url = clean_name(url)
        if not url:
            continue

        clubs.append(
            {
                "input_row": index,
                "input_club_name": None,
                "input_url": url,
                "base_transfer_url": normalize_transfer_url(url),
            }
        )

    return clubs


def season_start_year(value: str) -> int:
    value = value.strip()
    if "/" in value:
        value = value.split("/", 1)[0]

    year = int(value)
    if year < 100:
        return 1900 + year if year >= 80 else 2000 + year
    return year


def parse_seasons(values: list[str] | None) -> list[int] | None:
    if not values:
        return None

    seasons = []
    for value in values:
        for part in value.replace(",", " ").split():
            season = season_start_year(part)
            if season not in seasons:
                seasons.append(season)
    return seasons


async def discover_seasons(base_transfer_url: str) -> list[int]:
    crawler = ParselCrawler()
    seasons = []

    @crawler.router.default_handler
    async def parse(context):
        selector = context.selector
        for value in selector.xpath("//select[@name='saison_id']//option/@value").getall():
            if value and value.isdigit():
                seasons.append(int(value))

        if not seasons:
            title = clean_name(selector.xpath("string(//title)").get()) or ""
            match = re.search(r"(\d{2})/(\d{2})", title)
            if match:
                seasons.append(2000 + int(match.group(1)))

    await crawler.run([Request.from_url(base_transfer_url, unique_key=f"{base_transfer_url}#{uuid.uuid4()}")])
    return sorted(set(seasons), reverse=True)


async def scrape_club_season(club: dict, season: int) -> tuple[list[dict], dict]:
    url = season_url(club["base_transfer_url"], season)
    club_href = extract_club_href(url)
    crawler = ParselCrawler()
    rows = []
    page_seen = False
    page_title = None

    @crawler.router.default_handler
    async def parse(context):
        nonlocal page_seen, page_title
        page_seen = True
        selector = context.selector
        title_name = clean_name(selector.xpath("string(//title)").get())
        page_title = title_name
        club_name = title_name.split(" - Transfers", 1)[0] if title_name else None
        club_name = clean_name(club_name) or club["input_club_name"]

        tables = selector.xpath(
            "//table[.//th[contains(., 'Fee')] "
            "and (.//th[contains(., 'Left')] or .//th[contains(., 'Joined')])]"
        )

        parent = {
            "type": "club",
            "href": club_href,
            "seasoned_href": url,
            "input_row": club["input_row"],
            "input_club_name": club["input_club_name"],
            "input_url": club["input_url"],
        }

        for table in tables:
            rows.extend(parse_transfer_table(table, parent, club_name, club_href, season))

    status = {
        "input_row": club["input_row"],
        "input_club_name": club["input_club_name"],
        "input_url": club["input_url"],
        "season": f"{season % 100:02d}/{(season + 1) % 100:02d}",
        "season_start_year": season,
        "source_url": url,
        "status": "pending",
        "attempt": None,
        "rows_found": 0,
        "page_title": None,
        "error": None,
    }

    try:
        await crawler.run([Request.from_url(url, unique_key=f"{url}#{uuid.uuid4()}")])
        status["rows_found"] = len(rows)
        status["page_title"] = page_title
        if not page_seen:
            status["status"] = "failed"
            status["error"] = "Crawler finished without parsing the page"
        elif rows:
            status["status"] = "ok"
        else:
            status["status"] = "zero_rows"
    except Exception as exc:
        status["status"] = "failed"
        status["error"] = str(exc)

    return rows, status


async def scrape_club_season_with_retries(
    club: dict,
    season: int,
    retries: int,
    retry_delay: float,
) -> tuple[list[dict], dict]:
    rows = []
    last_status = None

    for attempt in range(1, retries + 2):
        rows, status = await scrape_club_season(club, season)
        status["attempt"] = attempt
        last_status = status

        if status["status"] != "failed":
            return rows, status

        if attempt <= retries:
            sleep_seconds = retry_delay * attempt
            print(f"    Retry {attempt}/{retries} after {sleep_seconds:.1f}s: {status['error']}")
            await asyncio.sleep(sleep_seconds)

    return rows, last_status


def flatten_transfer(item: dict) -> dict:
    parent = item.get("parent") or {}
    season = item.get("season")

    return {
        "input_row": parent.get("input_row"),
        "input_club_name": parent.get("input_club_name"),
        "input_url": parent.get("input_url"),
        "season": f"{season % 100:02d}/{(season + 1) % 100:02d}" if season else None,
        "season_start_year": season,
        "direction": item.get("direction"),
        "club_id": item.get("club_id"),
        "club_name": item.get("club_name"),
        "player_id": item.get("player_id"),
        "player_name": item.get("player_name"),
        "age": item.get("age"),
        "nationalities": ", ".join(item.get("nationalities") or []),
        "position": item.get("position"),
        "position_short": item.get("position_short"),
        "market_value": item.get("market_value"),
        "market_value_in_eur": money_to_eur(item.get("market_value")),
        "from_club_id": item.get("from_club_id"),
        "from_club_name": item.get("from_club_name"),
        "to_club_id": item.get("to_club_id"),
        "to_club_name": item.get("to_club_name"),
        "fee": item.get("fee"),
        "fee_in_eur": money_to_eur(item.get("fee")),
        "player_href": item.get("player_href"),
        "from_club_href": item.get("from_club_href"),
        "to_club_href": item.get("to_club_href"),
        "source_url": parent.get("seasoned_href"),
    }


def save_jsonl(rows: list[dict], jsonl_file: Path) -> None:
    jsonl_file.parent.mkdir(parents=True, exist_ok=True)
    with jsonl_file.open("w", encoding="utf-8") as output_file:
        for row in rows:
            output_file.write(json.dumps(row, ensure_ascii=False) + "\n")


def save_xlsx(rows: list[dict], statuses: list[dict], xlsx_file: Path) -> None:
    xlsx_file.parent.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame([flatten_transfer(row) for row in rows])
    status_df = pd.DataFrame(statuses)

    if not df.empty:
        df = df.drop_duplicates(
            subset=[
                "input_row",
                "season_start_year",
                "direction",
                "player_id",
                "from_club_id",
                "to_club_id",
                "fee",
            ]
        )

    with pd.ExcelWriter(xlsx_file, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="transfers")
        worksheet = writer.sheets["transfers"]
        worksheet.freeze_panes = "A2"
        worksheet.auto_filter.ref = worksheet.dimensions

        status_df.to_excel(writer, index=False, sheet_name="scrape_status")
        status_worksheet = writer.sheets["scrape_status"]
        status_worksheet.freeze_panes = "A2"
        status_worksheet.auto_filter.ref = status_worksheet.dimensions

        for sheet in (worksheet, status_worksheet):
            for column_cells in sheet.columns:
                max_length = max(
                    len(str(cell.value)) if cell.value is not None else 0
                    for cell in column_cells
                )
                sheet.column_dimensions[column_cells[0].column_letter].width = min(
                    max(max_length + 2, 12),
                    60,
                )

    print(f"Saved {len(df)} transfer rows to {xlsx_file}")


async def run(args: argparse.Namespace) -> tuple[list[dict], list[dict]]:
    if args.urls:
        clubs = club_links_from_urls(args.urls)
        source_label = "direct URL arguments"
    else:
        clubs = read_club_links(args.input, args.header_row, args.sheet)
        source_label = f"{args.input}" + (f" sheet '{args.sheet}'" if args.sheet else "")

    if args.limit_clubs:
        clubs = clubs[: args.limit_clubs]

    print(f"Loaded {len(clubs)} club links from {source_label}")
    all_rows = []
    statuses = []

    for club_index, club in enumerate(clubs, start=1):
        explicit_seasons = parse_seasons(args.seasons)
        if explicit_seasons:
            print(f"[{club_index}/{len(clubs)}] Using requested seasons for {club['input_club_name'] or club['input_url']}")
            seasons = explicit_seasons
        else:
            print(f"[{club_index}/{len(clubs)}] Discovering seasons for {club['input_club_name'] or club['input_url']}")
            seasons = await discover_seasons(club["base_transfer_url"])
            if args.limit_seasons:
                seasons = seasons[: args.limit_seasons]

        print(f"  Found {len(seasons)} seasons: {', '.join(map(str, seasons[:10]))}")
        for season_index, season in enumerate(seasons, start=1):
            print(f"  [{season_index}/{len(seasons)}] Scraping {season}/{season + 1}")
            if args.request_delay > 0:
                await asyncio.sleep(args.request_delay)

            rows, status = await scrape_club_season_with_retries(
                club,
                season,
                retries=args.retries,
                retry_delay=args.retry_delay,
            )
            statuses.append(status)
            print(f"    {len(rows)} transfer rows ({status['status']})")
            if status["error"]:
                print(f"    Error: {status['error']}")
            all_rows.extend(rows)

    return all_rows, statuses


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Read Transfermarkt club links from Excel, scrape all transfer seasons, and export XLSX."
    )
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--sheet", default=None, help="Excel sheet name to read. Defaults to the active sheet.")
    parser.add_argument("--header-row", type=int, default=2)
    parser.add_argument("--jsonl", type=Path, default=DEFAULT_JSONL)
    parser.add_argument("--xlsx", type=Path, default=DEFAULT_XLSX)
    parser.add_argument(
        "--urls",
        nargs="+",
        default=None,
        help="Optional direct club URLs. If provided, the Excel input is skipped.",
    )
    parser.add_argument(
        "--seasons",
        nargs="+",
        default=None,
        help="Specific seasons to scrape, e.g. --seasons 24 25 26 or --seasons 24/25 25/26",
    )
    parser.add_argument("--limit-clubs", type=int, default=None)
    parser.add_argument("--limit-seasons", type=int, default=None)
    parser.add_argument(
        "--request-delay",
        type=float,
        default=2.0,
        help="Seconds to wait before each club-season request.",
    )
    parser.add_argument(
        "--retries",
        type=int,
        default=3,
        help="Retry count for failed club-season requests.",
    )
    parser.add_argument(
        "--retry-delay",
        type=float,
        default=20.0,
        help="Base seconds to wait before retries; multiplied by attempt number.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows, statuses = asyncio.run(run(args))
    save_jsonl(rows, args.jsonl)
    save_xlsx(rows, statuses, args.xlsx)
    print(f"Saved raw JSONL to {args.jsonl}")


if __name__ == "__main__":
    main()
