Transfermarkt Excel Transfer Scraper
====================================

Files in this package:
- scrape_excel_club_transfers_all_seasons.py
- requirements.txt

Setup on another PC:

1. Install Python 3.10 or newer.

2. Open PowerShell in this folder.

3. Create a virtual environment:

   python -m venv .venv

4. Activate it:

   .\.venv\Scripts\Activate.ps1

5. Install dependencies:

   python -m pip install -r requirements.txt

6. Put your Excel file in this same folder.
   By default the script looks for:

   to_extract.xlsx

Expected Excel format:
- Header row defaults to row 2.
- Required header: Link
- Optional header: Club name
- Links can be visible text or Excel hyperlinks.

Run for seasons 24/25, 25/26, and 26/27:

   python scrape_excel_club_transfers_all_seasons.py --seasons 24 25 26 --input to_extract.xlsx --xlsx outputs\transfers_24_25_26.xlsx --jsonl outputs\transfers_24_25_26.json

Run a specific sheet:

   python scrape_excel_club_transfers_all_seasons.py --sheet failed_retry --seasons 24 25 26 --input to_extract.xlsx --xlsx outputs\failed_retry_transfers_24_25_26.xlsx --jsonl outputs\failed_retry_transfers_24_25_26.json

Useful slower/politer run:

   python scrape_excel_club_transfers_all_seasons.py --seasons 24 25 26 --request-delay 5 --retries 5 --retry-delay 30

Output workbook sheets:
- transfers
- scrape_status

Status meanings:
- ok: page scraped and transfer rows found
- zero_rows: page loaded but no transfer rows found
- failed: request or parser failed after retries
