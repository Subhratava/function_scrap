# Transfermarkt Portable Scrapers

These files are for running:

- `scrape_player_profiles_from_transfers.py`
- `scrape_player_performance_details.py`

Use Python 3.10 or newer.

Install dependencies:

```powershell
python -m pip install -r requirements_portable_scrapers.txt
```

Example runs:

```powershell
python scrape_player_profiles_from_transfers.py --input transfers.xlsx --sheet "Player data"
python scrape_player_performance_details.py --input player_profiles.xlsx --sheet "Player data"
```

The scripts write Excel and JSON files under `outputs` by default.
