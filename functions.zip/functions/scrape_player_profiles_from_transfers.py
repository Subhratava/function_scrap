import argparse
import asyncio
import json
import re
import time
import uuid
from pathlib import Path
from urllib.parse import urlparse

import pandas as pd
import requests
from crawlee import Request
from crawlee.crawlers import ParselCrawler
from openpyxl import load_workbook


BASE_URL = "https://www.transfermarkt.com"
TRANSFER_HISTORY_API = "https://www.transfermarkt.co.uk/ceapi/transferHistory/list/"
DEFAULT_INPUT = Path("..") / "transfers.xlsx"
DEFAULT_OUTPUT = Path("outputs") / "player_profiles_and_transfer_history.xlsx"
DEFAULT_RAW_JSON = Path("outputs") / "player_profiles_and_transfer_history.json"


def clean_text(value: str | None) -> str | None:
    if value is None:
        return None
    return " ".join(str(value).replace("\xa0", " ").split()).strip() or None


def selector_text(selector) -> str | None:
    return clean_text(" ".join(selector.xpath(".//text()").getall()))


def money_to_eur(value: str | None) -> float | None:
    value = clean_text(value)
    if value is None or value in {"", "-", "?"}:
        return None
    if value == "free transfer":
        return 0.0
    if not value.startswith("\u20ac"):
        return 0.0

    amount = value[1:].replace(",", ".")
    multiplier = 1.0
    if amount.endswith("m"):
        multiplier = 1_000_000.0
        amount = amount[:-1]
    elif amount.endswith("k"):
        multiplier = 1_000.0
        amount = amount[:-1]

    try:
        return float(amount) * multiplier
    except ValueError:
        return None


def absolute_url(href: str | None) -> str | None:
    href = clean_text(href)
    if not href:
        return None
    if href.startswith("http"):
        return href
    return f"{BASE_URL}{href}"


def player_id_from_href(href: str | None) -> str | None:
    if not href:
        return None
    parts = urlparse(href).path.rstrip("/").split("/")
    if parts and parts[-1].isdigit():
        return parts[-1]
    return None


def club_id_from_href(href: str | None) -> str | None:
    if not href:
        return None
    parts = urlparse(href).path.rstrip("/").split("/")
    if "verein" in parts:
        index = parts.index("verein")
        if index + 1 < len(parts):
            return parts[index + 1]
    for part in reversed(parts):
        if part.isdigit():
            return part
    return None


def profile_url_from_href(href: str) -> str:
    return absolute_url(href)


def transfer_history_url_from_href(href: str) -> str | None:
    player_id = player_id_from_href(href)
    if not player_id:
        return None
    return f"{TRANSFER_HISTORY_API}{player_id}"


def read_players(input_file: Path, sheet_name: str | None, player_href_column: str) -> list[dict]:
    wb = load_workbook(input_file, read_only=True, data_only=True)
    ws = wb[sheet_name] if sheet_name else wb[wb.sheetnames[0]]

    header = [clean_text(cell.value) for cell in next(ws.iter_rows(min_row=1, max_row=1))]
    header_lookup = {name: index for index, name in enumerate(header) if name}
    if player_href_column not in header_lookup:
        raise ValueError(f"Could not find column '{player_href_column}' in {input_file}")

    href_idx = header_lookup[player_href_column]
    name_idx = header_lookup.get("player_name")
    id_idx = header_lookup.get("player_id")

    seen = set()
    players = []
    for row_number, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        href = clean_text(row[href_idx]) if href_idx < len(row) else None
        if not href:
            continue

        player_id = clean_text(row[id_idx]) if id_idx is not None and id_idx < len(row) else player_id_from_href(href)
        key = player_id or href
        if key in seen:
            continue
        seen.add(key)

        players.append(
            {
                "input_row": row_number,
                "player_id": player_id,
                "input_player_name": clean_text(row[name_idx]) if name_idx is not None and name_idx < len(row) else None,
                "player_href": href,
                "profile_url": profile_url_from_href(href),
            }
        )

    return players


def parse_info_table(selector) -> dict:
    fields = {}
    labels = selector.xpath("//span[contains(@class,'info-table__content--regular')]")
    for label in labels:
        key = clean_text(label.xpath("string()").get())
        if not key:
            continue
        key = key.rstrip(":")
        value_node = label.xpath("following-sibling::span[contains(@class,'info-table__content--bold')][1]")
        fields[key] = selector_text(value_node) if value_node else None
    return fields


def split_birth_age(value: str | None) -> tuple[str | None, str | None]:
    value = clean_text(value)
    if not value:
        return None, None
    match = re.match(r"(.+?)\s*\(([^)]+)\)", value)
    if match:
        return clean_text(match.group(1)), clean_text(match.group(2))
    return value, None


def parse_profile_page(selector, player: dict, status: str, error: str | None = None) -> dict:
    info = parse_info_table(selector)
    page_title = clean_text(selector.xpath("string(//title)").get())
    headline = clean_text(selector.xpath("string(//h1)").get())
    date_of_birth, age = split_birth_age(info.get("Date of birth/Age"))

    current_club_href = selector.xpath(
        "//span[contains(@class,'info-table__content--regular') and contains(., 'Current club')]/"
        "following-sibling::span[contains(@class,'info-table__content--bold')][1]//a/@href"
    ).get()

    return {
        "player_id": player["player_id"] or player_id_from_href(player["player_href"]),
        "input_player_name": player["input_player_name"],
        "player_name": headline,
        "player_href": player["player_href"],
        "profile_url": player["profile_url"],
        "page_title": page_title,
        "date_of_birth": date_of_birth,
        "age": age,
        "citizenship": info.get("Citizenship"),
        "position": info.get("Position"),
        "current_club": info.get("Current club"),
        "current_club_id": club_id_from_href(current_club_href),
        "current_club_href": current_club_href,
        "current_club_url": absolute_url(current_club_href),
        "joined": info.get("Joined"),
        "contract_expires": info.get("Contract expires"),
        "height": info.get("Height"),
        "foot": info.get("Foot"),
        "status": status,
        "error": error,
    }


async def scrape_profile(player: dict) -> dict:
    crawler = ParselCrawler()
    parsed = {"seen": False, "data": None}

    @crawler.router.default_handler
    async def parse(context):
        parsed["seen"] = True
        parsed["data"] = parse_profile_page(context.selector, player, "ok")

    try:
        await crawler.run([Request.from_url(player["profile_url"], unique_key=f"{player['profile_url']}#{uuid.uuid4()}")])
    except Exception as exc:
        return {
            "player_id": player["player_id"] or player_id_from_href(player["player_href"]),
            "input_player_name": player["input_player_name"],
            "player_name": None,
            "player_href": player["player_href"],
            "profile_url": player["profile_url"],
            "status": "failed",
            "error": str(exc),
        }

    if parsed["data"]:
        return parsed["data"]

    return {
        "player_id": player["player_id"] or player_id_from_href(player["player_href"]),
        "input_player_name": player["input_player_name"],
        "player_name": None,
        "player_href": player["player_href"],
        "profile_url": player["profile_url"],
        "status": "failed",
        "error": "Crawler finished without parsing the profile page",
    }


def fetch_transfer_history(player: dict, retries: int, retry_delay: float) -> list[dict]:
    player_id = player["player_id"] or player_id_from_href(player["player_href"])
    if not player_id:
        return []

    url = f"{TRANSFER_HISTORY_API}{player_id}"
    headers = {
        "Accept": "application/json",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": player["profile_url"],
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "X-Requested-With": "XMLHttpRequest",
    }

    last_error = None
    for attempt in range(1, retries + 2):
        try:
            response = requests.get(url, headers=headers, timeout=45)
            if response.status_code >= 500 and attempt <= retries:
                last_error = f"HTTP {response.status_code}"
                time.sleep(retry_delay * attempt)
                continue
            if response.status_code >= 400:
                last_error = f"HTTP {response.status_code}"
                break

            body = response.json()
            transfers = body.get("transfers") or []
            return [
                flatten_transfer_history(player, transfer, url)
                for transfer in transfers
            ]
        except Exception as exc:
            last_error = str(exc)
            if attempt <= retries:
                time.sleep(retry_delay * attempt)

    return [
        {
            "player_id": player_id,
            "input_player_name": player["input_player_name"],
            "player_href": player["player_href"],
            "profile_url": player["profile_url"],
            "history_api_url": url,
            "status": "failed",
            "error": last_error,
        }
    ]


def flatten_transfer_history(player: dict, transfer: dict, api_url: str) -> dict:
    from_club = transfer.get("from") or {}
    to_club = transfer.get("to") or {}
    fee = transfer.get("fee")
    market_value = transfer.get("marketValue")

    return {
        "player_id": player["player_id"] or player_id_from_href(player["player_href"]),
        "input_player_name": player["input_player_name"],
        "player_href": player["player_href"],
        "profile_url": player["profile_url"],
        "history_api_url": api_url,
        "transfer_url": absolute_url(transfer.get("url")),
        "transfer_id": player_id_from_href(transfer.get("url")),
        "transfer_date": transfer.get("dateUnformatted"),
        "transfer_date_text": transfer.get("date"),
        "transfer_season": transfer.get("season"),
        "from_club_id": club_id_from_href(from_club.get("href")),
        "from_club_name": from_club.get("clubName"),
        "from_club_href": from_club.get("href"),
        "from_club_url": absolute_url(from_club.get("href")),
        "to_club_id": club_id_from_href(to_club.get("href")),
        "to_club_name": to_club.get("clubName"),
        "to_club_href": to_club.get("href"),
        "to_club_url": absolute_url(to_club.get("href")),
        "market_value": market_value,
        "market_value_in_eur": money_to_eur(market_value),
        "fee": fee,
        "fee_in_eur": money_to_eur(fee),
        "status": "ok",
        "error": None,
    }


def save_json(raw: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")


def save_xlsx(player_rows: list[dict], history_rows: list[dict], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        pd.DataFrame(player_rows).to_excel(writer, index=False, sheet_name="Player data")
        pd.DataFrame(history_rows).to_excel(writer, index=False, sheet_name="Transfer history")

        for worksheet in writer.sheets.values():
            worksheet.freeze_panes = "A2"
            worksheet.auto_filter.ref = worksheet.dimensions
            for column_cells in worksheet.columns:
                max_length = max(
                    len(str(cell.value)) if cell.value is not None else 0
                    for cell in column_cells
                )
                worksheet.column_dimensions[column_cells[0].column_letter].width = min(
                    max(max_length + 2, 12),
                    60,
                )


async def run(args: argparse.Namespace) -> tuple[list[dict], list[dict]]:
    players = read_players(args.input, args.sheet, args.player_href_column)
    if args.limit_players:
        players = players[: args.limit_players]

    print(f"Loaded {len(players)} unique players from {args.input}")
    player_rows = []
    history_rows = []

    for index, player in enumerate(players, start=1):
        print(f"[{index}/{len(players)}] {player['input_player_name'] or player['player_href']}")
        if args.request_delay > 0:
            await asyncio.sleep(args.request_delay)

        profile = await scrape_profile(player)
        player_rows.append(profile)

        history = fetch_transfer_history(player, args.retries, args.retry_delay)
        history_rows.extend(history)
        print(f"  profile={profile.get('status')} history_rows={len(history)}")

    return player_rows, history_rows


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Scrape Transfermarkt player profile data and transfer history from a transfer output workbook."
    )
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--sheet", default=None, help="Input sheet name. Defaults to first sheet.")
    parser.add_argument("--player-href-column", default="player_href")
    parser.add_argument("--xlsx", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--json", type=Path, default=DEFAULT_RAW_JSON)
    parser.add_argument("--limit-players", type=int, default=None)
    parser.add_argument("--request-delay", type=float, default=1.5)
    parser.add_argument("--retries", type=int, default=3)
    parser.add_argument("--retry-delay", type=float, default=15.0)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    player_rows, history_rows = asyncio.run(run(args))
    save_json({"player_data": player_rows, "transfer_history": history_rows}, args.json)
    save_xlsx(player_rows, history_rows, args.xlsx)
    print(f"Saved {len(player_rows)} player rows and {len(history_rows)} transfer-history rows to {args.xlsx}")
    print(f"Saved raw JSON to {args.json}")


if __name__ == "__main__":
    main()
